using System;
using Writer;

namespace Estado
{
class Bloqueo
{
  public int Bloqueo(String[] datos)

  {

    int estado = 0;
    Escritura esc = new Escritura();
    String adminombre = "";
    if (int.Parse(datos[2]) > 3)
    datos[2] = "3";
    do
    {

      if(adminombre != datos[0])
      Console.WriteLine("Ingresar correctamente el nombre del usuario requerido");
      Console.WriteLine("Ingresar el nombre del usuario");
      adminombre = Console.ReadLine();
      } while (adminombre != datos[0]);
      do
      {
        if (int.Parse(datos[2]) <)
      
          break;
          }
          Console.WriteLine($"Ingresar la contraseña {datos[0]}");
          adminombre = Console.ReadLine();
          if (adminombre != datos[1].Trim())
          {

            datos[2] = (int.Parse(datos[2]) -1).ToString();
            esc.Write(datos, "admindato", "datoadmin.dll");
            Console.WriteLine($"Contraseña no valida, intentos restantes: {datos[2]}");
            }
            if (int.Parse(datos[2]) <1)
            {
              break;
              }
              } while(adminombre != datos[1].Trim ('') && int.Parse(datos[2]) >= 1);
              estado = int.Parse(datos[2]);
              Console.Clear();
              return estado;

              }
              }
              }

using System;
using System.IO;

namespace Writer
{
  class Escrito
  {
    staticStreamWriter Escribir;

    public void Write(String[] datos, String carpeta, String archivo)
    {
      String txtcomplt = "";
      String[] wordmn = new String[0];
      int tamaño = 0, f = 0;
      String directorio = Path.GetFullPath(@""+ carpeta);
      String drcttxt = Path.GetFullPath($@"{carpeta}\{archivo}");
      File.Delete(drcttxt);
      Escribir = new StreamWriter(drcttxt, true);
      foreach (String cache in datos)
      {
        if (f < datos.Length -1)
        Escribir.Write(datos[f] + " ,");
        if (f >= datos.Length -1)
        Escribir.Write(datos[f]);
        f++
        }
tamaño = txtcomplt.Split(',').Length;
wordmn = new String[tamaño];
Escribir.Close();
}
}
}

using System;
using System.IO;
using System.IO.Compression;

namespace Out
{
  class Output
  {

    staticStreamWriter Escribir;
    public void Escritofin(String[,] datos, Double[,] salarios, String[] maymen)
    {
      String[] complementos = {"Nombre del empleado: ", "Puesto del empleado: ", "Codigo del empleado: ",
      "Horas trabajadas: ", "ISSS: $", "AFP: $", "Renta: $", "Sueldo L: $", "Sueldo N: $", "Bonos:$"};
      String[,] chainexit = new String[3, 10];

      for(int x = 0; x < 3; x++)
      {
        for (int y = 0; y < 10; y++)
        {
          if(y < 3)
          {
            chainexit[x, y] = datos [x, y];
            }
            else
            {
              chainexit[x, y] = salarios[x, y - 3].ToString();
              }
              }
              }

String localdate = "calcularSalario_ " + DateTime.Today.Day + DateTime.Today.Month + DateTime.Today.Year + "_" + DateTime.Now.Hour + DateTime.Now.Minute;
String drcttxt = Path.GetFullPath($@"calculoEmpleado\{localdate}.txt");
String cachetxt = Path.Combine($@"c:\{localdate}\{localdate}.txt"), strache = "", outputg = "";
Escribir = new StreamWriter(drcttxt, true);

for (int x = 0, y = 0; x < 3; x++)
{
  for(y = 0; y <10; y++)
  {
    if (y < 9)
    {
      outputg = complementos[y] + chainexit[x, y] + "\n";
      }
      else
      {
        if (salarios[x, 6] <= 0)
        {
          outputg = "No hay bonos.\n";
          } else
          {
            outputg = complementos[y] + chainexit[x, y] + "\n";
            }

            Escribir.Write(outputg);
            strache += outputg;
            Console.Write(outputg);

            }
            Escribir.Write("\n");
                strache += "\n";
                Console.Write("\n");
                Console.WriteLine("Presionar cualquier tecla para continuar");
                Console.ReadKey();
                Console.Clear();

                 }
            Escribir.Write($"{maymen[0]} Gana menos\n{maymen[1]} Gana más\n{maymen[2]} Gana(n) más de $300\n");
            strache += $"{maymen[0]} Gana menos\n{maymen[1]} Gana más\n{maymen[2]} Gana(n) más de $300\n";
            Console.Write($"{maymen[0]} Gana menos\n{maymen[1]} Gana más\n{maymen[2]} Gana(n) más de $300\n");
            Escribir.Close();

             Directory.CreateDirectory($@"c:\{localdate}");
            Escribir = new StreamWriter(cachetxt, true);
            Escribir.Write(strache);
            Escribir.Close();
            String ziptxt = Path.GetFullPath($@"hist\{localdate}.zip");
            ZipFile.CreateFromDirectory($@"c:\{localdate}", ziptxt);
            File.Delete($@"c:\{localdate}\{localdate}.txt");
            Directory.Delete($@"c:\{localdate}");
        }
    }
}                      

using System;
using System.Linq;


namespace Numeros
{
  class Numerico
  {
    public Double[,] Calculo(String[,]) hora)
    {
      Double[,] salarios = new Double[3, 7];
      Double Cache = 0;
      for (int x = 0; x < 3; x++)
      {
        salarios[x, 0] = Double.Parse(hora[x, 3]);
        if (salarios[x, 0] > 160)
        {
          Cache = (160 * 9.75) + ((salarios[x, 0]- 160) * 11.5);
        }
        else
        {
          Cache = salarios[x, 0] * 9.75;
        }
        salarios[x, 4] = Math.Truncate((Cache) * 100) / 100;
                salarios[x, 6] = Bonos(horas, salarios[x, 4]);
                salarios[x, 1] = Math.Truncate((salarios[x, 4] * 0.0525) * 100) / 100;
                salarios[x, 2] = Math.Truncate((salarios[x, 4] * 0.0688) * 100) / 100;
                salarios[x, 3] = Math.Truncate((salarios[x, 4] * 0.1) * 100) / 100;
                salarios[x, 5] = salarios[x, 4] - (salarios[x, 1] + salarios[x, 2] + salarios[x, 3]) + salarios[x, 6];
      }
      return salarios;
    }
    private Double Bonos(String[,] Data, Double sb)
  {

    Double bono = 0;
    if (Data[0, 1] == "Gerente" && Data[1, 1] == "Asistente" && Data[2, 1] == "Secretaria")
  {
    for (int x = 0; x < 3; x++)
    bono = 0;
  }
  else
  {
    for (int x= 0; x < 3; x++)
    {
      if (Data[x, 1] == "Gerente")
                    {
                        bono = sb * 0.1;
                    }
                    else if (Data[x, 1] == "Asistente")
                    {
                        bono = sb * 0.05;
                    }
                    else if (Data[x, 1] == "Secretaria")
                    {
                        bono = sb * 0.03;
                    }
                    else
                    {
                        bono = sb * 0.02;
                    }
                }
            }
            return bono;
        }
public String[] Mymn300 (Double[,] sueldos, String[,] nombres)
{
  String[] resulmymn = new String[3];
            Double[] sl = new Double[3];
            Double mayorque = 0;
            for (int a = 0; a < 3; a++)
                sl[a] = sueldos[a, 5];

            for (int x = 0; x < 3; x++)
            {
                if (sl[x] > 300)
                {
                    mayorque++;
                }
                if (sl[x] == sl.Min())
                {
                    resulmymn[0] += $"{nombres[x, 0]} ";
                }
                if (sl[x] == sl.Max())
                {
                    resulmymn[1] += $"{nombres[x, 0]} ";
                }
            }
            resulmymn[2] = mayorque.ToString();
            return resulmymn;
        }
    }
}    

using System;
using System.IO;

namespace Process
{
  class Proceso
  {
    static StreamWriter Leer;
    static StreamWriter Escribir;

    public String[] Inicio()
    {
      String txtcomplt = "";
      String[] wordmn = new String[0];
      int tamaño = 0, f = 0;
      String directorio = Path.GetFullPath(@"admindato");
      String drcttxt = Path.GetFullPath(@"admindato\datoadmin.dll");
            if (!Directory.Exists(directorio))
            {
                Directory.CreateDirectory(directorio);
            }
            directorio = Path.GetFullPath(@"calculoEmpleado");
            if (!Directory.Exists(directorio))
            {
                Directory.CreateDirectory(directorio);
            }
            directorio = Path.GetFullPath(@"hist");
            if (!Directory.Exists(directorio))
            {
                Directory.CreateDirectory(directorio);
            }
            directorio = Path.Combine("c:");
            if (!Directory.Exists(directorio))
            {
                Directory.CreateDirectory(directorio);
            }
            if (!File.Exists(drcttxt))
            {
                Escribir = new StreamWriter(drcttxt, true);
                Escribir.Write("Admin, Contra, 3");
                Escribir.Close();
                }
            wordmn = new String[tamaño];
            foreach (String cache in txtcomplt.Split(','))
            {
                wordmn[f] = cache.Trim();
                f++;
            }
            f = 0;
            Leer.Close();
            int x = 0;
            if (!int.TryParse(wordmn[2], out x))
            {
                File.Delete(drcttxt);
                Escribir = new StreamWriter(drcttxt, true);
                Escribir.Write("Admin, Contra, 3");
                Escribir.Close();
                Leer = new StreamReader(drcttxt, true);
                txtcomplt = Leer.ReadToEnd();
                tamaño = txtcomplt.Split(',').Length;
                wordmn = new String[tamaño];
                foreach (String cache in txtcomplt.Split(','))
                {
                    wordmn[f] = cache.Trim();
                    f++;
                }
                Leer.Close();
            }
            return wordmn;
        }
    }
}                   
        
using System;

namespace Empleadata
{

class Dataemployee

{

public String[,] Wordemployee()
{
  String[] complementos = { "nombre", "puesto", "codigo", "horas trabajadas (numero)" };
  String[,] empleado = new String[3, 4];
  for (int y = 0; y < 4; y++)
  {
    do
    {
      try
      {
        Console.WriteLine($"Ingresar {complementos[y]} del empleado {x + 1}");
        empleado[x, y] = Console.ReadLine();
        if (y == 3 && int.Parse(empleado[x, y]) < 1)
                        {
              Console.WriteLine("Error, ingresar cantidad válida (valor positivo)");
                            }
                        }
                        catch (FormatException)
                        {
                            Console.WriteLine("Error de formato, escriba un valor numérico.");
                            empleado[x, y] = 0.ToString();
                        }
                    } while (y == 3 && int.Parse(empleado[x, y]) < 1);
                }
                Console.WriteLine("Presionar cualquier tecla para continuar");
                Console.ReadKey();
                Console.Clear();
            }
            return empleado;
        }
    }
}

using System;
using Process;
using Estado;
using Writer;
using Empleadata;
using Numeros;
using Out;

namespace MainClass
{

  class Programa
  {
    
    static Proceso Init = new Procesos();
    static Bloqueo State = new Bloqueo();
    static Escrito Escribir = new Escrito();
    static Dataemployee empleado = new Dataemployee();
    static Numeros sueldos = new Numeros();
    static Output Salida = new Output();

    static void Main(string[] args)
    {

      Console.Title = "Desafio Practico 3";
      String[] datosadmin = Init.Inicio();
      int bloq = State.Bloqueos(datosadmin);
      datosadmin[2] = bloq.toString();
      Escribir.Write(datosadmin, "admindato", "datoadmin.dll");
      if (bloq < 1)
      {
        Consol.WriteLine("Usuario bloqueado, presionar cualquier tecla para salir.");
      }
      else
      {
        String[,] datosempleado = Empleado.Wordemployee();
        Double[,] salarios = Sueldos.Calculos(datosempleado);
        String[] mayormenor = Sueldos.Mymn300(salarios, datosempleado);
        Salida.Escritofin(datosempleado, salarios, mayormenor);
      }
      Console.WriteLine("Gracias por usar el servicio, presionar cualquier tecla para salir. ");
      Console.ReadKey();
    }
  }
}





    
      
      










