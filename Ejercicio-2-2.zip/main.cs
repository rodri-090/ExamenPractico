using System;

class MainClass {
  public static void Main (string[] args) {
   


int[] num = new int[10];
for (int i = 0; i <num.Length; i++)


{

Console.WriteLine("Ingresar el dígito "+(i + 1)+":");
num[i] = int.Parse(Console.ReadLine());



while (num[i] < 0)
{
  Console.WriteLine("Ingresar numero valido ");
  num[i] = int.Parse(Console.ReadLine());

}
while (num[i] > 500)

{

Console.WriteLine("Ingresar numero valido ");
num[i] = int.Parse(Console.ReadLine());

}

}

Console.WriteLine("Multiplos de 5 : ");
for (int i = 0; i < num.Length; i++)
{
  if (num[i] % 5 == 0)
  {
    Console.WriteLine(num[i]);
    }
    }


    Console.WriteLine("Multiplos de 3 : ");
    for (int i = 0; i <num.Length; i++)
    {
      if (num[i] % 3 == 0)
      {
        Console.WriteLine(num[i]);
        }
        }
        Console.ReadKey();
        }
        }
        
