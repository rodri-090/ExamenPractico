using System;

class MainClass {
  public static void Main (string[] args) {
    Console.WriteLine ("Ingresar nota1");
    double num1 = Convert.ToDouble(Console.ReadLine());

  

Console.WriteLine ("Ingresar nota2");
    double num2 = Convert.ToDouble(Console.ReadLine());




    Console.WriteLine ("Ingresar nota3");
double num3 = Convert.ToDouble(Console.ReadLine());

double prom = (num1 + num2 + num3) / 3;

if (prom >=7)

{
  Console.WriteLine("Promocionado");

}

else if (prom >= 4)
{
  Console.WriteLine("Regular");

  }

  else if (prom < 4)
  {
    Console.WriteLine("Reprobado");


    Console.WriteLine();


  }
  }
  }