using System;

class MainClass {
  public static void Main (string[] args) {
    
    Console.WriteLine ("Ingresar el primer numero");
    double num1 = Convert.ToDouble(Console.ReadLine());
    
    
    Console.WriteLine ("Ingresar el segundo numero");
    double num2 = Convert.ToDouble(Console.ReadLine());
    
    
  Console.WriteLine ("Ingresar el tercer numero");
  double num3 = Convert.ToDouble(Console.ReadLine());      
  
  
  Console.WriteLine ("Ingresar el cuarto numero");
    double num4 = Convert.ToDouble(Console.ReadLine());

    Console.WriteLine("La suma de los primeros dos numeros es:");
    
    Console.WriteLine(num1 + num2);
    
    Console.WriteLine("El producto de los ultimos dos numeros es:");
    
    Console.WriteLine(num3*num4);
    
    
  Console.WriteLine();
  }
}