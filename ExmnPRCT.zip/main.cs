using System;


class MainClass {
  public static void Main (string[] args) {


double sum1 = 0, sum2 = 0, sum3 = 0, sum4 = 0, sum5 = 0;
double promed1 = 0, promed2 = 0, promed3 = 0, promed4 = 0, promed5 = 0;
string nameSt1, nameSt2, nameSt3, nameSt4, nameSt5;


Console.Write("¿Nombre del alumno 1? ");
nameSt1 = Console.ReadLine();

double[] nota1 = new double[5];
for (int i = 0; i < 5; i++)
{


Console.Write("¿Cuál es la nota " + (i + 1) + "? ");
nota1[i] = Double.Parse(Console.ReadLine());
while (nota1[i] < 0)
{

  Console.WriteLine("Ingresar nota valida :");
  nota1[i] = int.Parse(Console.ReadLine());
  }
  while (nota1[i] > 10)
  {
    Console.WriteLine("Ingresar nota valida:");
    nota1[i] = int.Parse(Console.ReadLine());
    }
    sum1 = nota1[i] + sum1;
    }

    promed1 = sum1 / 5;

Console.Write("¿Nombre del alumno 2? ");
nameSt2 = Console.ReadLine();

double[] nota2 = new double[5];
for (int i = 0; i < 5; i++)
{


Console.Write("¿Cuál es la nota " + (i + 1) + "? ");
nota2[i] = Double.Parse(Console.ReadLine());
while (nota2[i] < 0)
{

  Console.WriteLine("Ingresar nota valida :");
  nota2[i] = int.Parse(Console.ReadLine());
  }
  while (nota2[i] > 10)
  {
    Console.WriteLine("Ingresar nota valida:");
    nota2[i] = int.Parse(Console.ReadLine());
    }
    sum2 = nota2[i] + sum2;
    }

    promed2 = sum2 / 5;



    Console.Write("¿Nombre del alumno 3? ");
nameSt3 = Console.ReadLine();

double[] nota3 = new double[5];
for (int i = 0; i < 5; i++)
{


Console.Write("¿Cuál es la nota " + (i + 1) + "? ");
nota3[i] = Double.Parse(Console.ReadLine());
while (nota3[i] < 0)
{

  Console.WriteLine("Ingresar nota valida :");
  nota3[i] = int.Parse(Console.ReadLine());
  }
  while (nota3[i] > 10)
  {
    Console.WriteLine("Ingresar nota valida:");
    nota3[i] = int.Parse(Console.ReadLine());
    }
    sum3 = nota3[i] + sum3;
    }

    promed3 = sum3 / 5;



    Console.Write("¿Nombre del alumno 4? ");
nameSt4 = Console.ReadLine();

double[] nota4 = new double[5];
for (int i = 0; i < 5; i++)
{


Console.Write("¿Cuál es la nota " + (i + 1) + "? ");
nota4[i] = Double.Parse(Console.ReadLine());
while (nota4[i] < 0)
{

  Console.WriteLine("Ingresar nota valida :");
  nota4[i] = int.Parse(Console.ReadLine());
  }
  while (nota4[i] > 10)
  {
    Console.WriteLine("Ingresar nota valida:");
    nota4[i] = int.Parse(Console.ReadLine());
    }
    sum4 = nota4[i] + sum4;
    }

    promed4 = sum4 / 5;



    Console.Write("¿Nombre del alumno 5? ");
nameSt5 = Console.ReadLine();

double[] nota5 = new double[5];
for (int i = 0; i < 5; i++)
{


Console.Write("¿Cuál es la nota " + (i + 1) + "? ");
nota5[i] = Double.Parse(Console.ReadLine());
while (nota5[i] < 0)
{

  Console.WriteLine("Ingresar nota valida :");
  nota5[i] = int.Parse(Console.ReadLine());
  }
  while (nota5[i] > 10)
  {
    Console.WriteLine("Ingresar nota valida:");
    nota5[i] = int.Parse(Console.ReadLine());
    }
    sum5 = nota5[i] + sum5;
    }

    promed5 = sum5 / 5;
    Console.Clear();

    if (promed1 >= 7)
    {
      Console.WriteLine("Nombre de alumno : " + nameSt1 + " (Aprobado)");
      }
      else if (promed1 >= 4 &&promed1 < 7)
      {
        Console.WriteLine(" Nombre de alumno : " + nameSt1 + " (Regular)");
        }
        else 
        {
          Console.WriteLine(" Nombre de alumno : " + nameSt1 + " (Reprobado)");
          }

          if (promed1 > promed2 && promed1 > promed3 && promed1 > promed4 && promed1 > promed5)
          {
            Console.WriteLine(" El promedio es : " + promed1 + " (Mayor promedio");
            }
            else
            {
              Console.WriteLine(" El promedio es : : " + promed1);
              }

              if (promed2 >= 7)
              {
                Console.WriteLine(" Nombre de alumno : " + nameSt2 + " (Aprobado)");
                }
                else if (promed2 >= 4 && promed2 < 7)
                {
                  Console.WriteLine(" Nombre de alumno : " + nameSt2 + " (Regular)");
                  }
                  else
                  {
                    Console.WriteLine(" Nombre de alumno : " + nameSt2 + " (Reprobado)");
                    }

                    if (promed2 > promed1 && promed2 > promed3 && promed2 > promed4 && promed2 > promed5)

                    {
                      Console.WriteLine(" El promedio es : " + promed2 + " (Mayor promedio");
                      }
                      else
                      {
                        Console.WriteLine(" El promedio es: " + promed2);

                        }

                        if (promed3 >= 7)
                        {
                          Console.WriteLine(" Nombre de alumno : " + nameSt3 + " (Aprobado)");
                          }
                          else if (promed3 >= 4 && promed3 < 7)
                          {
                            Console.WriteLine(" Nombre del alumno : " + nameSt3 + " (Regular)");

                            }
                            else 
                            {
                              Console.WriteLine("Nombre de alumno : " + nameSt3 + " (Reprobado)");

                            }



                            if (promed3 > promed1 && promed3 > promed2 && promed3 > promed4 && promed3 > promed5)
                            {
                              Console.WriteLine(" El promedio es : " + promed3 +  " (Mayor promedio");
                              }
                              else
                              {
                                Console.WriteLine(" El promedio es: " + promed3);
                               }


                               if (promed4 >= 7)
                        {
                          Console.WriteLine(" Nombre de alumno : " + nameSt4 + " (Aprobado)");
                          }
                          else if (promed4 >= 4 && promed4 < 6.99)
                          {
                            Console.WriteLine(" Nombre del alumno : " + nameSt4 + " (Regular)");

                            }
                            else 
                            {
                              Console.WriteLine("Nombre de alumno : " + nameSt4 + " (Reprobado)");

                            }



                            if (promed4 > promed1 && promed4 > promed2 && promed4 > promed3 && promed4 > promed5)
                            {
                              Console.WriteLine(" El promedio es : " + promed4 +  " (Mayor promedio");
                              }
                              else
                              {
                                Console.WriteLine(" El promedio es: " + promed4);
                               }

                               if (promed5 >= 7)
                        {
                          Console.WriteLine(" Nombre de alumno : " + nameSt5 + " (Aprobado)");
                          }
                          else if (promed5 >= 4 && promed5 < 7)
                          {
                            Console.WriteLine(" Nombre del alumno : " + nameSt5 + " (Regular)");

                            }
                            else 
                            {
                              Console.WriteLine("Nombre de alumno : " + nameSt5 + " (Reprobado)");

                            }



                            if (promed5 > promed1 && promed5 > promed2 && promed5 > promed4 && promed5 > promed4)
                            {
                              Console.WriteLine(" El promedio es : " + promed5 +  " (Mayor promedio");
                              }
                              else
                              {
                                Console.WriteLine(" El promedio es: " + promed5);
                               }
                               Console.ReadKey();
                               }
                               }
                               
