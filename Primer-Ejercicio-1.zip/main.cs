using System;

class MainClass {
  public static void Main (string[] args) {
    int amount = 0;
    double price = 0;

    Console.WriteLine("Ingresar el precio del articulo");
    price = Convert.ToDouble(Console.ReadLine());

    Console.WriteLine("Ingresar la cantidad de los articulos");
    amount = Int32.Parse(Console.ReadLine());

    Console.WriteLine("Total: $" + price * amount);
  }
}